# JustBuy 🛒🇹🇿

**Shop the world. Delivered to Tanzania.**

Paste any product link from Amazon, ASOS, AliExpress, eBay, Zara and more — see your full landed cost in TZS before you buy. JustBuy handles purchase, shipping, customs and delivery.

---

## How this repo is structured

```
justbuy/
├── public/
│   └── index.html              ← Entire frontend (HTML + CSS + JS)
├── netlify/
│   └── functions/
│       ├── scrape.js           ← POST /.netlify/functions/scrape
│       └── order.js            ← POST /.netlify/functions/order
├── netlify.toml                ← Netlify build + function config
├── package.json                ← Only dependency: cheerio
├── .env.example                ← Env var template (safe to commit)
└── .gitignore
```

No framework. No build step. Pure static HTML + Netlify Functions.

---

## Deploy to Netlify (no Node.js needed locally)

### 1. Upload to GitHub (in the browser)

1. Go to **github.com → New repository** → name it `justbuy` → Create
2. Click **"uploading an existing file"**
3. Drag the entire contents of this folder into the upload area
4. Commit changes

### 2. Connect to Netlify

1. Go to **app.netlify.com → Add new site → Import an existing project**
2. Choose **GitHub** → select the `justbuy` repo
3. Netlify reads `netlify.toml` automatically — no settings to change
4. Click **Deploy site**

Netlify runs `npm install` (installs cheerio) on their servers.
Your `public/` folder is served as static files.
Your `netlify/functions/` are deployed as serverless functions.

### 3. Set environment variables

In Netlify → **Site configuration → Environment variables** → Add:

| Variable | Where to get it |
|---|---|
| `SCRAPERAPI_KEY` | scraperapi.com → Dashboard |
| `EXCHANGERATE_KEY` | exchangerate-api.com → Dashboard |
| `TWILIO_ACCOUNT_SID` | console.twilio.com → Account Info |
| `TWILIO_AUTH_TOKEN` | console.twilio.com → Account Info |
| `TWILIO_WHATSAPP_FROM` | `whatsapp:+14155238886` (sandbox default) |
| `WHATSAPP_OPS_NUMBER` | Your number e.g. `+255700000000` |

Then go to **Deploys → Trigger deploy** to redeploy with the new vars.

### 4. Connect your domain

Netlify → **Domain management → Add custom domain** → `justbuytz.shop`

Update your DNS:
```
A     @    75.2.60.5
CNAME www  [your-site].netlify.app
```

---

## API endpoints

### `POST /.netlify/functions/scrape`

Fetches and parses a product page, returns cost breakdown.

```json
// Request
{ "url": "https://www.amazon.com/dp/B09XS7JWHH" }

// Response (success)
{
  "scraped": true,
  "title": "Sony WH-1000XM5 Headphones",
  "image": "https://...",
  "source": "amazon.com",
  "priceUSD": 279.99,
  "rate": 2615,
  "breakdown": {
    "itemTZS": 731974,
    "shippingTZS": 26150,
    "serviceTZS": 36599,
    "dutyTZS": 109796,
    "totalTZS": 904519,
    "totalUSD": 345.91
  }
}

// Response (price not found → frontend shows manual form)
{ "scraped": false, "source": "shein.com" }
```

### `POST /.netlify/functions/order`

Captures an order and sends WhatsApp notifications via Twilio.

```json
// Request
{
  "name": "Amina Mwangi",
  "phone": "+255712345678",
  "productTitle": "Sony WH-1000XM5",
  "productUrl": "https://amazon.com/...",
  "totalTZS": 904519,
  "priceUSD": 279.99
}

// Response
{ "success": true, "message": "Order received!" }
```

---

## Cost formula

```
Total = (priceUSD × rate)      ← item in TZS
      + (10 × rate)            ← ~1kg air freight
      + (5% × itemTZS)         ← JustBuy service fee
      + (15% × itemTZS)        ← estimated customs duty
```

Constants are at the top of `netlify/functions/scrape.js`.

---

## Scraping fallback chain

1. **ScraperAPI** — rotating residential proxies + JS rendering
2. **JSON-LD structured data** — parsed from fetched HTML
3. **Open Graph meta tags** — parsed from fetched HTML
4. **Store-specific CSS selectors** — Amazon, eBay, AliExpress, ASOS, Zara
5. **Manual entry form** — shown when price can't be extracted (Shein etc.)

---

## WhatsApp setup (Twilio)

**For testing:** Use the Twilio WhatsApp Sandbox (free).
- Go to console.twilio.com → Messaging → Try it out → Send a WhatsApp message
- Your ops number and test customers need to opt in to the sandbox first

**For production:** Apply for a Twilio WhatsApp Business sender.
- This takes 1–2 weeks for approval
- Costs ~$1/mo for the number + per-message fees

---

## Branch strategy

```
main     ← production (auto-deploys to justbuytz.shop)
develop  ← active work (creates a Netlify preview URL)
```

Create a `develop` branch in GitHub for day-to-day work.
Merge to `main` only when tested and ready.
